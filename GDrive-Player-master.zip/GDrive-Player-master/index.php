// Please don't edit this page if you just try it. Cause this page build for structure program. //

<?php
if(isset($_POST['files'])){
include ('header.php');
include ('player.php');
include ('footer.php');
}
else {
    include('generator.php');
}
?>
